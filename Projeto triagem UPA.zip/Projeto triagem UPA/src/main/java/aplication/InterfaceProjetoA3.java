package aplication;

public class InterfaceProjetoA3 {

    public static void main(String[] args) {

    }
}
